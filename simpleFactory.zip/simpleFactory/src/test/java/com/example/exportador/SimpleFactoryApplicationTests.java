package com.example.exportador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleFactoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
